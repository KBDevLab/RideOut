import { Notifications } from './notifications';

describe('Notifications', () => {
  it('should create an instance', () => {
    expect(new Notifications()).toBeTruthy();
  });
});
