import { Reviews } from './reviews';

describe('Reviews', () => {
  it('should create an instance', () => {
    expect(new Reviews()).toBeTruthy();
  });
});
