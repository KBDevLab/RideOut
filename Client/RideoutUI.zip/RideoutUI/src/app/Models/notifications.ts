export class Notifications {
}
