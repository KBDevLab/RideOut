export interface User {
    UserID: string;
    Name: string;
    Email: string;
    PasswordHash: string;
    Location: string;
    ProfilePicture: string;
    Bio: string;
    CreatedAt: Date;
    UpdatedAt: Date;
  }