export class Rideout {
}
