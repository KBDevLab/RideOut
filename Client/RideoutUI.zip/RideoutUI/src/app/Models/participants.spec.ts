import { Participants } from './participants';

describe('Participants', () => {
  it('should create an instance', () => {
    expect(new Participants()).toBeTruthy();
  });
});
