import { Messages } from './messages';

describe('Messages', () => {
  it('should create an instance', () => {
    expect(new Messages()).toBeTruthy();
  });
});
