import { Rideout } from './rideout';

describe('Rideout', () => {
  it('should create an instance', () => {
    expect(new Rideout()).toBeTruthy();
  });
});
