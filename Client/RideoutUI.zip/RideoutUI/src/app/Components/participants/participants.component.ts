import { Component } from '@angular/core';

@Component({
  selector: 'app-participants',
  imports: [],
  templateUrl: './participants.component.html',
  styleUrl: './participants.component.css'
})
export class ParticipantsComponent {

}
