import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { UserService } from '../../Services/user.service';
import { User } from '../../Models/user';

@Component({
  selector: 'app-user',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.scss']
})
export class UserComponent implements OnInit {
  user: User | null = null;

  constructor(
    private route: ActivatedRoute,
    private userService: UserService
  ) {}

  ngOnInit(): void {
    this.route.paramMap.subscribe(params => {
      const userId = params.get('id');
      if (userId) {
        this.userService.getUserById(userId).subscribe(user => {
          this.user = user;
        });
      }
    });
  }

  editUser(): void {
    console.log('Edit user functionality');
    // Implement edit logic here or navigate to an edit page
  }

  deleteUser(): void {
    console.log('Delete user functionality');
    // Implement delete logic here
  }
}