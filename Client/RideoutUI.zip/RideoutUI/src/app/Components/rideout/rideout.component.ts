import { Component } from '@angular/core';

@Component({
  selector: 'app-rideout',
  imports: [],
  templateUrl: './rideout.component.html',
  styleUrl: './rideout.component.css'
})
export class RideoutComponent {

}
