import { Component } from '@angular/core';

@Component({
  selector: 'app-notitfications',
  imports: [],
  templateUrl: './notitfications.component.html',
  styleUrl: './notitfications.component.css'
})
export class NotitficationsComponent {

}
